// Function to prompt user for the main ingredient
async function getOrder() {
  let ingredient = prompt("Enter the ingredient you would like: ")
    .toLowerCase()
    .replace(/\s+/g, "_");
  let meal = await getMealByIngredient();

  if (!meal) {
    alert("No meals found with that ingredient. Please enter a new one: ");
    return takeOrder();
  }

  let order = createOrder(meal);
  saveOrder(meal);
  alert(`Order placed: ${order.description} (Order No: ${order.orderNumber})`);
}

// Getting order by ingredient using Meal DB API
async function getMealByIngredient(ingredient) {
  let response = await fetch(
    `https://www.themealdb.com/api/json/v1/1/filter.php?i=${ingredient}`
  );
  let data = await response.json();
  if (!data.meals) return null;
  return data.meals[Math.floor(Math.random() * data.meals.length)].strMeal;
}

function createOrder(mealDescription) {
  let orderNumber = getLastOrderNumber() + 1;
  return {
    orderNumber,
    description: mealDescription,
    status: "incomplete",
  };
}

// function that saves order to sessionStorage
function saveOrder(order) {
  let orders = JSON.parse(sessionStorage.getItem("orders")) || [];
  orders.push(order);
  sessionStorage.setItem("orders", JSON.stringify(orders));
  sessionStorage.setItem("lastOrderNumber", order.orderNumber);
}

function getLastOrderNumber() {
  return parseInt(sessionStorage.getItem("lastOrderNumber")) || 0;
}

function completeOrder() {
  let orders = JSON.parse(sessionStorage.getItem("orders")) || [];
  let incompleteOrders = orders.filter(
    (order) => order.status === "incomplete"
  );

  if (incompleteOrders.length === 0) {
    alert("No incomplete orders found");
    return;
  }

  let orderDescriptions = incompleteOrders
    .map(
      (order) => `Order No: ${order.orderNumber}, Description: ${description}`
    )
    .join("\n");
  let orderNumber = prompt(
    `Incomplete orders:\n${orderDescriptions}\n\nEnter the order number to maark as complete, or 0 to cancel: `
  );

  if (orderNumber === "0") {
    return;
  }

  let order = orders.find((order) => order.orderNumber == orderNumber);

  if (!order) {
    alert("Order number not found.");
    return completeOrder();
  }

  order.status = "complete";
  sessionStorage.setItem("orders", JSON.stringify(orders));
  alert(`Order No: ${orderNumber} marked as complete.`);
}

// Start the order process when the page loads
window.onload = function () {
  takeOrder();
};
